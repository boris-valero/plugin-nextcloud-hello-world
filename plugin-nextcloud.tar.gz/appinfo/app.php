<?php
use OCP\AppFramework\App;

$app = new App('myapp');
$container = $app->getContainer();